package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.TransactionType
import com.example.data.repository.TransactionRepository
import com.example.ui.viewmodel.FinanceViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var database: AppDatabase
    private lateinit var repository: TransactionRepository

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .setQueryExecutor { it.run() }
            .setTransactionExecutor { it.run() }
            .build()
        repository = TransactionRepository(database.transactionDao())
    }

    @After
    fun tearDown() {
        database.close()
        Dispatchers.resetMain()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("KeuanganKuu", appName)
    }

    @Test
    fun `fresh database is completely empty with no seed data`() = runTest(testDispatcher) {
        val items = repository.allTransactions.first()
        assertTrue("Database baru harus kosong", items.isEmpty())

        val viewModel = FinanceViewModel(repository)
        advanceUntilIdle()

        val afterInit = repository.allTransactions.first()
        assertTrue("ViewModel init tidak boleh mengisi data contoh", afterInit.isEmpty())
    }

    @Test
    fun `form rejects invalid chars and validates zero nominal`() = runTest(testDispatcher) {
        val viewModel = FinanceViewModel(repository)
        viewModel.openAddForm()
        viewModel.setFormType(TransactionType.PENGELUARAN)
        viewModel.setFormCategory("Kopi")

        // Reject letters, spaces, dots, minus
        viewModel.setFormAmount("25.000abc -")
        assertEquals("25000", viewModel.formAmount.value)

        // Zero or empty fails validation
        viewModel.setFormAmount("0")
        viewModel.saveTransaction()
        advanceUntilIdle()
        assertEquals("Nominal harus lebih dari 0", viewModel.formError.value)
        assertTrue(repository.allTransactions.first().isEmpty())

        // Valid amount saves as pure Long
        viewModel.setFormAmount("25000")
        viewModel.saveTransaction()
        advanceUntilIdle()

        val saved = repository.allTransactions.first()
        assertEquals(1, saved.size)
        assertEquals(25000L, saved.first().amount)
    }

    @Test
    fun `custom label saves, formats displayTitle, pre-fills edit, and aggregates under parent category`() = runTest(testDispatcher) {
        val viewModel = FinanceViewModel(repository)

        // 1. Add transaction with customLabel
        viewModel.openAddForm()
        viewModel.setFormType(TransactionType.PENGELUARAN)
        viewModel.setFormCategory("Belanja")
        viewModel.setFormCustomLabel("Nasi Padang")
        viewModel.setFormAmount("25000")
        viewModel.saveTransaction()
        advanceUntilIdle()

        // 2. Add transaction without customLabel under same parent category
        viewModel.openAddForm()
        viewModel.setFormType(TransactionType.PENGELUARAN)
        viewModel.setFormCategory("Belanja")
        viewModel.setFormAmount("15000")
        viewModel.saveTransaction()
        advanceUntilIdle()

        val all = repository.allTransactions.first()
        assertEquals(2, all.size)

        val withLabel = all.first { it.amount == 25000L }
        val withoutLabel = all.first { it.amount == 15000L }

        assertEquals("Belanja · Nasi Padang", withLabel.displayTitle)
        assertEquals("Belanja", withoutLabel.displayTitle)

        // 3. Edit pre-fills customLabel
        viewModel.openEditForm(withLabel)
        assertEquals("Nasi Padang", viewModel.formCustomLabel.value)

        // 4. Max 50 chars enforcement
        val longText = "A".repeat(65)
        viewModel.setFormCustomLabel(longText)
        assertEquals(50, viewModel.formCustomLabel.value.length)

        // 5. Category summary aggregates under parent "Belanja" (25000 + 15000 = 40000)
        val summaries = viewModel.categorySummaries.first { it.isNotEmpty() }
        assertEquals(1, summaries.size)
        assertEquals("Belanja", summaries.first().category)
        assertEquals(40000L, summaries.first().totalAmount)
        assertEquals(2, summaries.first().count)
    }

    @Test
    fun `recentCustomLabels returns distinct labels up to 8 most recent`() = runTest(testDispatcher) {
        val viewModel = FinanceViewModel(repository)
        val labels = listOf(
            "Nasi Padang", "Gorengan", "Parkir", "Donasi",
            "Nasi Padang", // duplicate
            "Laundry", "Boba", "Cuci Motor", "Bakso", "Soto"
        )
        labels.forEachIndexed { index, label ->
            viewModel.openAddForm()
            viewModel.setFormCategory("Belanja")
            viewModel.setFormCustomLabel(label)
            viewModel.setFormAmount(((index + 1) * 5000).toString())
            viewModel.saveTransaction()
            advanceUntilIdle()
        }

        val recent = repository.recentCustomLabels.first()
        assertEquals(8, recent.size)
        assertEquals(recent.distinct().size, recent.size)
        assertTrue(recent.contains("Soto"))
        assertTrue(recent.contains("Nasi Padang"))
    }
}
