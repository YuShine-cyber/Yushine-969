package com.example

import androidx.compose.ui.text.AnnotatedString
import com.example.util.FormatUtils
import com.example.util.ThousandSeparatorVisualTransformation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    private val transformation = ThousandSeparatorVisualTransformation()

    @Test
    fun `thousand separator formats digits correctly`() {
        assertEquals("", transformation.filter(AnnotatedString("")).text.text)
        assertEquals("2", transformation.filter(AnnotatedString("2")).text.text)
        assertEquals("25", transformation.filter(AnnotatedString("25")).text.text)
        assertEquals("250", transformation.filter(AnnotatedString("250")).text.text)
        assertEquals("2.500", transformation.filter(AnnotatedString("2500")).text.text)
        assertEquals("25.000", transformation.filter(AnnotatedString("25000")).text.text)
        assertEquals("1.250.000", transformation.filter(AnnotatedString("1250000")).text.text)
    }

    @Test
    fun `thousand separator offset mapping is valid and consistent`() {
        val inputs = listOf("", "2", "25", "250", "2500", "25000", "1250000", "9876543210")
        for (input in inputs) {
            val result = transformation.filter(AnnotatedString(input))
            val transformed = result.text.text
            val mapping = result.offsetMapping

            var prevTrans = -1
            for (i in 0..input.length) {
                val mapped = mapping.originalToTransformed(i)
                assertTrue("Mapped $mapped out of bounds for '$input'", mapped in 0..transformed.length)
                assertTrue("Non-monotonic originalToTransformed for '$input'", mapped >= prevTrans)
                assertEquals("Round-trip failed for '$input' at $i", i, mapping.transformedToOriginal(mapped))
                prevTrans = mapped
            }

            var prevOrig = -1
            for (j in 0..transformed.length) {
                val mapped = mapping.transformedToOriginal(j)
                assertTrue("Mapped $mapped out of bounds for '$transformed'", mapped in 0..input.length)
                assertTrue("Non-monotonic transformedToOriginal for '$transformed'", mapped >= prevOrig)
                prevOrig = mapped
            }
        }
    }

    @Test
    fun `formatRupiah formats zero and positive and negative amounts`() {
        assertEquals("Rp 0", FormatUtils.formatRupiah(0L))
        assertEquals("Rp 25.000", FormatUtils.formatRupiah(25_000L))
        assertEquals("Rp 1.250.000", FormatUtils.formatRupiah(1_250_000L))
        assertEquals("-Rp 25.000", FormatUtils.formatRupiah(-25_000L))
    }
}
