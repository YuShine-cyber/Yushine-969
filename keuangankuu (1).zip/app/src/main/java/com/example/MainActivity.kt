package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AppDatabase
import com.example.data.repository.TransactionRepository
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.TransactionFormSheet
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SummaryScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.FinanceViewModelFactory

data class NavTabItem(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {

    private val viewModel: FinanceViewModel by viewModels {
        val database = AppDatabase.getInstance(applicationContext)
        val repository = TransactionRepository(database.transactionDao())
        FinanceViewModelFactory(repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: FinanceViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isFormOpen by viewModel.isFormOpen.collectAsStateWithLifecycle()
    val editingTransaction by viewModel.editingTransaction.collectAsStateWithLifecycle()
    val formType by viewModel.formType.collectAsStateWithLifecycle()
    val formCategory by viewModel.formCategory.collectAsStateWithLifecycle()
    val formCustomLabel by viewModel.formCustomLabel.collectAsStateWithLifecycle()
    val recentCustomLabels by viewModel.recentCustomLabels.collectAsStateWithLifecycle()
    val formAmount by viewModel.formAmount.collectAsStateWithLifecycle()
    val formDateMillis by viewModel.formDateMillis.collectAsStateWithLifecycle()
    val formNote by viewModel.formNote.collectAsStateWithLifecycle()
    val formError by viewModel.formError.collectAsStateWithLifecycle()
    val transactionToDelete by viewModel.transactionToDelete.collectAsStateWithLifecycle()

    // Handle back button: if in a sub-tab, return to Beranda (tab 0)
    BackHandler(enabled = currentTab != 0) {
        viewModel.selectTab(0)
    }

    val tabs = listOf(
        NavTabItem(
            title = "Beranda",
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_tab_beranda"
        ),
        NavTabItem(
            title = "Riwayat",
            selectedIcon = Icons.Filled.ReceiptLong,
            unselectedIcon = Icons.Outlined.ReceiptLong,
            testTag = "nav_tab_riwayat"
        ),
        NavTabItem(
            title = "Ringkasan",
            selectedIcon = Icons.Filled.PieChart,
            unselectedIcon = Icons.Outlined.PieChart,
            testTag = "nav_tab_ringkasan"
        )
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("bottom_navigation_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                tabs.forEachIndexed { index, tab ->
                    val isSelected = currentTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(index) },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { tabIndex ->
                when (tabIndex) {
                    0 -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToHistory = { viewModel.selectTab(1) }
                    )
                    1 -> HistoryScreen(
                        viewModel = viewModel
                    )
                    2 -> SummaryScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // Modal Bottom Sheet Form (Add / Edit)
    TransactionFormSheet(
        isOpen = isFormOpen,
        editingTransaction = editingTransaction,
        currentType = formType,
        selectedCategory = formCategory,
        customLabelText = formCustomLabel,
        recentCustomLabels = recentCustomLabels,
        amountText = formAmount,
        dateMillis = formDateMillis,
        noteText = formNote,
        errorMessage = formError,
        onTypeChange = { viewModel.setFormType(it) },
        onCategoryChange = { viewModel.setFormCategory(it) },
        onCustomLabelChange = { viewModel.setFormCustomLabel(it) },
        onAmountChange = { viewModel.setFormAmount(it) },
        onAddQuickAmount = { viewModel.addQuickAmount(it) },
        onDateChange = { viewModel.setFormDateMillis(it) },
        onNoteChange = { viewModel.setFormNote(it) },
        onSave = { viewModel.saveTransaction() },
        onDelete = if (editingTransaction != null) {
            { viewModel.requestDelete(editingTransaction!!) }
        } else null,
        onDismiss = { viewModel.closeForm() }
    )

    // Delete Confirmation Dialog
    DeleteConfirmationDialog(
        transaction = transactionToDelete,
        onConfirm = { viewModel.confirmDelete() },
        onDismiss = { viewModel.cancelDelete() }
    )
}
