package com.example.util

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object FormatUtils {
    private val indonesianLocale = Locale("id", "ID")

    fun formatRupiah(amount: Long, includePrefix: Boolean = true): String {
        val symbols = DecimalFormatSymbols(indonesianLocale).apply {
            groupingSeparator = '.'
            decimalSeparator = ','
        }
        val decimalFormat = DecimalFormat("#,##0", symbols)
        val formattedNumber = decimalFormat.format(abs(amount))
        return when {
            !includePrefix -> if (amount < 0) "-$formattedNumber" else formattedNumber
            amount < 0 -> "-Rp $formattedNumber"
            else -> "Rp $formattedNumber"
        }
    }

    fun parseAmount(raw: String): Long {
        val digitsOnly = raw.filter { it.isDigit() }
        return digitsOnly.toLongOrNull() ?: 0L
    }

    fun formatDate(millis: Long): String {
        val sdf = SimpleDateFormat("d MMM yyyy", indonesianLocale)
        return sdf.format(Date(millis))
    }

    fun formatFullDate(millis: Long): String {
        val sdf = SimpleDateFormat("EEEE, d MMMM yyyy", indonesianLocale)
        return sdf.format(Date(millis))
    }

    fun formatMonthYear(millis: Long): String {
        val sdf = SimpleDateFormat("MMMM yyyy", indonesianLocale)
        return sdf.format(Date(millis))
    }

    fun getMonthKey(millis: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.US)
        return sdf.format(Date(millis))
    }
}

class ThousandSeparatorVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val digits = text.text
        val n = digits.length
        if (n == 0) {
            return TransformedText(AnnotatedString(""), OffsetMapping.Identity)
        }

        val sb = StringBuilder()
        val origToTrans = IntArray(n + 1)
        val transToOrig = mutableListOf<Int>()

        for (i in 0 until n) {
            if (i > 0 && (n - i) % 3 == 0) {
                sb.append('.')
                transToOrig.add(i)
            }
            origToTrans[i] = sb.length
            sb.append(digits[i])
            transToOrig.add(i)
        }
        origToTrans[n] = sb.length
        transToOrig.add(n)

        val transformedText = sb.toString()

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                val clamped = offset.coerceIn(0, n)
                return origToTrans[clamped]
            }

            override fun transformedToOriginal(offset: Int): Int {
                val clamped = offset.coerceIn(0, transformedText.length)
                return transToOrig[clamped]
            }
        }

        return TransformedText(AnnotatedString(transformedText), offsetMapping)
    }
}
