package com.example.data.repository

import com.example.data.local.TransactionDao
import com.example.data.model.TransactionEntity
import kotlinx.coroutines.flow.Flow

class TransactionRepository(private val dao: TransactionDao) {
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val recentTransactions: Flow<List<TransactionEntity>> = dao.getRecentTransactions(10)
    val recentCustomLabels: Flow<List<String>> = dao.getRecentCustomLabels()

    suspend fun insert(transaction: TransactionEntity): Long {
        return dao.insert(transaction)
    }

    suspend fun update(transaction: TransactionEntity) {
        dao.update(transaction)
    }

    suspend fun delete(transaction: TransactionEntity) {
        dao.delete(transaction)
    }

    suspend fun deleteById(id: Long) {
        dao.deleteById(id)
    }
}
