package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LaptopMac
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType(val label: String) {
    PENGELUARAN("Pengeluaran"),
    PEMASUKAN("Pemasukan")
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "PEMASUKAN" or "PENGELUARAN"
    val category: String,
    val customLabel: String = "",
    val amount: Long,
    val dateMillis: Long,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val transactionType: TransactionType
        get() = try {
            TransactionType.valueOf(type)
        } catch (e: Exception) {
            TransactionType.PENGELUARAN
        }

    val displayTitle: String
        get() = if (customLabel.isNotBlank()) "$category · $customLabel" else category
}

data class CategoryMeta(
    val name: String,
    val type: TransactionType,
    val icon: ImageVector,
    val color: Color
)

object CategoryRegistry {
    // Categories for Pengeluaran
    val expenseCategories = listOf(
        CategoryMeta("Belanja", TransactionType.PENGELUARAN, Icons.Default.ShoppingCart, Color(0xFFE11D48)),
        CategoryMeta("Kopi", TransactionType.PENGELUARAN, Icons.Default.Coffee, Color(0xFFD97706)),
        CategoryMeta("Kuota", TransactionType.PENGELUARAN, Icons.Default.Wifi, Color(0xFF2563EB)),
        CategoryMeta("Listrik", TransactionType.PENGELUARAN, Icons.Default.ElectricBolt, Color(0xFFEAB308)),
        CategoryMeta("Air", TransactionType.PENGELUARAN, Icons.Default.WaterDrop, Color(0xFF0284C7)),
        CategoryMeta("Bensin", TransactionType.PENGELUARAN, Icons.Default.LocalGasStation, Color(0xFFEA580C))
    )

    // Categories for Pemasukan
    val incomeCategories = listOf(
        CategoryMeta("Gaji", TransactionType.PEMASUKAN, Icons.Default.AccountBalanceWallet, Color(0xFF16A34A)),
        CategoryMeta("Bonus", TransactionType.PEMASUKAN, Icons.Default.CardGiftcard, Color(0xFF10B981)),
        CategoryMeta("Freelance", TransactionType.PEMASUKAN, Icons.Default.LaptopMac, Color(0xFF0D9488)),
        CategoryMeta("Lainnya", TransactionType.PEMASUKAN, Icons.Default.AttachMoney, Color(0xFF059669))
    )

    fun getCategoryMeta(name: String, type: TransactionType): CategoryMeta {
        val list = if (type == TransactionType.PEMASUKAN) incomeCategories else expenseCategories
        return list.find { it.name.equals(name, ignoreCase = true) }
            ?: CategoryMeta(
                name = name,
                type = type,
                icon = if (type == TransactionType.PEMASUKAN) Icons.Default.MoreHoriz else Icons.Default.Receipt,
                color = if (type == TransactionType.PEMASUKAN) Color(0xFF16A34A) else Color(0xFFE11D48)
            )
    }
}
