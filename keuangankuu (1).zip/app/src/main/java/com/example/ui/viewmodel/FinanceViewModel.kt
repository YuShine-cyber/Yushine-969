package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.CategoryRegistry
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.TransactionRepository
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class CategorySummary(
    val category: String,
    val totalAmount: Long,
    val count: Int,
    val percentage: Float // 0.0 to 1.0
)

data class MonthGroup(
    val monthYearTitle: String,
    val totalIncome: Long,
    val totalExpense: Long,
    val transactions: List<TransactionEntity>
)

class FinanceViewModel(
    private val repository: TransactionRepository
) : ViewModel() {

    // Navigation Tab (0 = Beranda, 1 = Riwayat, 2 = Ringkasan)
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    fun selectTab(tabIndex: Int) {
        _currentTab.value = tabIndex
    }

    // All and Recent Transactions
    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentTransactions: StateFlow<List<TransactionEntity>> = repository.recentTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentCustomLabels: StateFlow<List<String>> = repository.recentCustomLabels
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // History Filters
    private val _historyTypeFilter = MutableStateFlow("Semua") // "Semua", "PEMASUKAN", "PENGELUARAN"
    val historyTypeFilter: StateFlow<String> = _historyTypeFilter.asStateFlow()

    private val _historyCategoryFilter = MutableStateFlow("Semua")
    val historyCategoryFilter: StateFlow<String> = _historyCategoryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setHistoryTypeFilter(type: String) {
        _historyTypeFilter.value = type
        _historyCategoryFilter.value = "Semua"
    }

    fun setHistoryCategoryFilter(category: String) {
        _historyCategoryFilter.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Filtered Transactions Grouped by Month
    val groupedHistory: StateFlow<List<MonthGroup>> = combine(
        allTransactions,
        _historyTypeFilter,
        _historyCategoryFilter,
        _searchQuery
    ) { transactions, typeFilter, catFilter, query ->
        val filtered = transactions.filter { item ->
            val matchesType = when (typeFilter) {
                "PEMASUKAN" -> item.type == "PEMASUKAN"
                "PENGELUARAN" -> item.type == "PENGELUARAN"
                else -> true
            }
            val matchesCategory = (catFilter == "Semua") || item.category.equals(catFilter, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                    item.category.contains(query, ignoreCase = true) ||
                    item.customLabel.contains(query, ignoreCase = true) ||
                    item.note.contains(query, ignoreCase = true)

            matchesType && matchesCategory && matchesQuery
        }

        // Group by Year-Month
        val groups = linkedMapOf<String, MutableList<TransactionEntity>>()
        for (item in filtered) {
            val key = FormatUtils.formatMonthYear(item.dateMillis)
            val list = groups.getOrPut(key) { mutableListOf() }
            list.add(item)
        }

        groups.map { (monthTitle, items) ->
            var income = 0L
            var expense = 0L
            for (item in items) {
                if (item.type == "PEMASUKAN") income += item.amount
                else expense += item.amount
            }
            MonthGroup(
                monthYearTitle = monthTitle,
                totalIncome = income,
                totalExpense = expense,
                transactions = items
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Summary calculations
    val totalIncome: StateFlow<Long> = allTransactions.combine(_currentTab) { list, _ ->
        list.filter { it.type == "PEMASUKAN" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalExpense: StateFlow<Long> = allTransactions.combine(_currentTab) { list, _ ->
        list.filter { it.type == "PENGELUARAN" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentBalance: StateFlow<Long> = combine(totalIncome, totalExpense) { inc, exp ->
        inc - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Summary Tab State
    private val _summaryType = MutableStateFlow(TransactionType.PENGELUARAN)
    val summaryType: StateFlow<TransactionType> = _summaryType.asStateFlow()

    private val _summaryTimeRange = MutableStateFlow("Semua Waktu") // "Semua Waktu" or "Bulan Ini"
    val summaryTimeRange: StateFlow<String> = _summaryTimeRange.asStateFlow()

    fun setSummaryType(type: TransactionType) {
        _summaryType.value = type
    }

    fun setSummaryTimeRange(range: String) {
        _summaryTimeRange.value = range
    }

    val categorySummaries: StateFlow<List<CategorySummary>> = combine(
        allTransactions,
        _summaryType,
        _summaryTimeRange
    ) { list, targetType, timeRange ->
        val now = Calendar.getInstance()
        val currentYear = now.get(Calendar.YEAR)
        val currentMonth = now.get(Calendar.MONTH)

        val filtered = list.filter { item ->
            val matchesType = item.type == targetType.name
            val matchesTime = if (timeRange == "Bulan Ini") {
                val cal = Calendar.getInstance().apply { timeInMillis = item.dateMillis }
                cal.get(Calendar.YEAR) == currentYear && cal.get(Calendar.MONTH) == currentMonth
            } else {
                true
            }
            matchesType && matchesTime
        }

        val totalForType = filtered.sumOf { it.amount }
        val grouped = filtered.groupBy { it.category }

        grouped.map { (cat, items) ->
            val sum = items.sumOf { it.amount }
            val count = items.size
            val percentage = if (totalForType > 0) sum.toFloat() / totalForType.toFloat() else 0f
            CategorySummary(
                category = cat,
                totalAmount = sum,
                count = count,
                percentage = percentage
            )
        }.sortedByDescending { it.totalAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Form Modal State
    private val _isFormOpen = MutableStateFlow(false)
    val isFormOpen: StateFlow<Boolean> = _isFormOpen.asStateFlow()

    private val _editingTransaction = MutableStateFlow<TransactionEntity?>(null)
    val editingTransaction: StateFlow<TransactionEntity?> = _editingTransaction.asStateFlow()

    private val _formType = MutableStateFlow(TransactionType.PENGELUARAN)
    val formType: StateFlow<TransactionType> = _formType.asStateFlow()

    private val _formCategory = MutableStateFlow("Belanja")
    val formCategory: StateFlow<String> = _formCategory.asStateFlow()

    private val _formCustomLabel = MutableStateFlow("")
    val formCustomLabel: StateFlow<String> = _formCustomLabel.asStateFlow()

    private val _formAmount = MutableStateFlow("")
    val formAmount: StateFlow<String> = _formAmount.asStateFlow()

    private val _formDateMillis = MutableStateFlow(System.currentTimeMillis())
    val formDateMillis: StateFlow<Long> = _formDateMillis.asStateFlow()

    private val _formNote = MutableStateFlow("")
    val formNote: StateFlow<String> = _formNote.asStateFlow()

    private val _formError = MutableStateFlow<String?>(null)
    val formError: StateFlow<String?> = _formError.asStateFlow()

    // Delete confirmation dialog
    private val _transactionToDelete = MutableStateFlow<TransactionEntity?>(null)
    val transactionToDelete: StateFlow<TransactionEntity?> = _transactionToDelete.asStateFlow()

    fun openAddForm() {
        _editingTransaction.value = null
        _formType.value = TransactionType.PENGELUARAN
        _formCategory.value = "Belanja"
        _formCustomLabel.value = ""
        _formAmount.value = ""
        _formDateMillis.value = System.currentTimeMillis()
        _formNote.value = ""
        _formError.value = null
        _isFormOpen.value = true
    }

    fun openEditForm(transaction: TransactionEntity) {
        _editingTransaction.value = transaction
        _formType.value = transaction.transactionType
        _formCategory.value = transaction.category
        _formCustomLabel.value = transaction.customLabel
        _formAmount.value = transaction.amount.toString()
        _formDateMillis.value = transaction.dateMillis
        _formNote.value = transaction.note
        _formError.value = null
        _isFormOpen.value = true
    }

    fun closeForm() {
        _isFormOpen.value = false
        _editingTransaction.value = null
        _formError.value = null
    }

    fun setFormType(type: TransactionType) {
        _formType.value = type
        // Reset category to default of selected type
        _formCategory.value = if (type == TransactionType.PENGELUARAN) "Belanja" else "Gaji"
        _formError.value = null
    }

    fun setFormCategory(cat: String) {
        _formCategory.value = cat
        _formError.value = null
    }

    fun setFormCustomLabel(label: String) {
        _formCustomLabel.value = label.take(50)
    }

    fun setFormAmount(raw: String) {
        val digitsOnly = raw.filter { it.isDigit() }.take(15)
        val normalized = if (digitsOnly.isEmpty()) {
            ""
        } else {
            digitsOnly.trimStart('0').ifEmpty { "0" }
        }
        _formAmount.value = normalized
        _formError.value = null
    }

    fun addQuickAmount(delta: Long) {
        val current = _formAmount.value.filter { it.isDigit() }.toLongOrNull() ?: 0L
        val updated = current + delta
        _formAmount.value = updated.toString()
        _formError.value = null
    }

    fun setFormDateMillis(millis: Long) {
        _formDateMillis.value = millis
    }

    fun setFormNote(note: String) {
        _formNote.value = note
    }

    fun saveTransaction() {
        val cleanedDigits = _formAmount.value.replace(".", "").filter { it.isDigit() }
        val amount = cleanedDigits.toLongOrNull() ?: 0L
        if (cleanedDigits.isEmpty() || amount <= 0L) {
            _formError.value = "Nominal harus lebih dari 0"
            return
        }

        val category = _formCategory.value.trim()
        if (category.isEmpty()) {
            _formError.value = "Kategori wajib dipilih"
            return
        }

        viewModelScope.launch {
            val currentEdit = _editingTransaction.value
            val trimmedLabel = _formCustomLabel.value.trim().take(50)
            if (currentEdit != null) {
                // Update
                val updated = currentEdit.copy(
                    type = _formType.value.name,
                    category = category,
                    customLabel = trimmedLabel,
                    amount = amount,
                    dateMillis = _formDateMillis.value,
                    note = _formNote.value.trim()
                )
                repository.update(updated)
            } else {
                // Insert
                val newTransaction = TransactionEntity(
                    type = _formType.value.name,
                    category = category,
                    customLabel = trimmedLabel,
                    amount = amount,
                    dateMillis = _formDateMillis.value,
                    note = _formNote.value.trim()
                )
                repository.insert(newTransaction)
            }
            closeForm()
        }
    }

    fun requestDelete(transaction: TransactionEntity) {
        _transactionToDelete.value = transaction
    }

    fun cancelDelete() {
        _transactionToDelete.value = null
    }

    fun confirmDelete() {
        val item = _transactionToDelete.value ?: return
        viewModelScope.launch {
            repository.delete(item)
            _transactionToDelete.value = null
            // Also close edit dialog if deleting from edit modal
            if (_editingTransaction.value?.id == item.id) {
                closeForm()
            }
        }
    }
}

class FinanceViewModelFactory(
    private val repository: TransactionRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FinanceViewModel::class.java)) {
            return FinanceViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
