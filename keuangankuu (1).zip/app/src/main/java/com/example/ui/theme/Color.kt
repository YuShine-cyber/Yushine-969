package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Brand
val EmeraldPrimary = Color(0xFF006C4C)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFF8CF7C6)
val EmeraldOnPrimaryContainer = Color(0xFF002114)

val EmeraldPrimaryDark = Color(0xFF70DAAB)
val EmeraldOnPrimaryDark = Color(0xFF003825)
val EmeraldPrimaryContainerDark = Color(0xFF005238)
val EmeraldOnPrimaryContainerDark = Color(0xFF8CF7C6)

// Income (Green)
val IncomeGreen = Color(0xFF15803D)
val IncomeGreenLight = Color(0xFFDCFCE7)
val IncomeGreenDark = Color(0xFF4ADE80)
val IncomeGreenDarkContainer = Color(0xFF052E16)

// Expense (Red)
val ExpenseRed = Color(0xFFDC2626)
val ExpenseRedLight = Color(0xFFFEE2E2)
val ExpenseRedDark = Color(0xFFF87171)
val ExpenseRedDarkContainer = Color(0xFF450A0A)

// Secondary & Tertiary
val SecondaryTeal = Color(0xFF4D6356)
val SecondaryTealDark = Color(0xFFB4CCBD)
val TertiaryGold = Color(0xFFB48300)
val TertiaryGoldDark = Color(0xFFF2C04B)

// Surfaces
val LightBackground = Color(0xFFF7FAF7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2EBE4)

val DarkBackground = Color(0xFF101512)
val DarkSurface = Color(0xFF171E1A)
val DarkSurfaceVariant = Color(0xFF232D27)
